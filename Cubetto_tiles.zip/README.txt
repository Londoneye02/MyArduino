                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2722440
Cubetto tiles by makkuro is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

You can print now more coding blocks for your cubetto playset (the one from Primotoys). Each coding block has the correct number and placement of holes on its back. So just put in magnets (3mm length, 2mm diameter) and use some glue so they stay in.

The coding blocks which come with the cubetto (forward, left, right, function) are included. Also the special ones (backward, negation, random) which are only included in the kickstarter campaign are included. I was lacking the latter, couldnt order them, so i designed this replacement.

To get the correct color, you could either print each coding block in the correct color (see https://www.primotoys.com/ as a reference) or stick coloured paper on top of each block.

If you like the tiles, also look into my configurable text based creations, e.g. [name plate](https://www.thingiverse.com/thing:714444), [Customizable text box with lid](https://www.thingiverse.com/thing:2627327), [round text](https://www.thingiverse.com/thing:681203) and [sweeping name plate](https://www.thingiverse.com/thing:678211).   And look at my [configurable pack of dogs](https://www.thingiverse.com/thing:2663881) and [rabbits](https://www.thingiverse.com/thing:2720329).

Please post your makes as "i made one"! I am curious what my customizable designs are used for and wether printing works out well. Also if you have ideas or wishes, let me know.

Have fun!